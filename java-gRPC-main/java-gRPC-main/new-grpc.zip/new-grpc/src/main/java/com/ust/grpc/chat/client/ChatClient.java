package com.ust.grpc.chat.client;

import com.proto.chat.ChatMessage;
import com.proto.chat.ChatServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class ChatClient {
    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50054)
                .usePlaintext()
                .build();

        ChatServiceGrpc.ChatServiceStub asyncClient = ChatServiceGrpc.newStub(channel);
        CountDownLatch latch = new CountDownLatch(1);

        StreamObserver<ChatMessage> requestObserver = asyncClient.chat(new StreamObserver<ChatMessage>() {
            @Override
            public void onNext(ChatMessage chatMessage) {
                System.out.println(chatMessage.getMessage());
            }

            @Override
            public void onError(Throwable throwable) {
                throwable.printStackTrace();
                latch.countDown();
            }

            @Override
            public void onCompleted() {
                latch.countDown();
            }
        });
        new Thread(() -> {
            try{
                String[] messages = {"Hi", "How are you?", "Bye!"};
                for(String msg : messages){
                    requestObserver.onNext(ChatMessage.newBuilder()
                            .setMessage(msg)
                            .build());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }finally{
                requestObserver.onCompleted();
            }
        }).start();
        try {
            latch.await(10, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        channel.shutdown();
    }
}
