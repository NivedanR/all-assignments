package com.ust.grpc.chat.server;

import com.proto.chat.ChatMessage;
import com.proto.chat.ChatServiceGrpc;
import io.grpc.stub.StreamObserver;

public class ChatServiceImpl extends ChatServiceGrpc.ChatServiceImplBase {
    @Override
    public StreamObserver<ChatMessage> chat(StreamObserver<ChatMessage> responseObserver) {
        return new StreamObserver<ChatMessage>() {
            @Override
            public void onNext(ChatMessage chatMessage) {
                System.out.println("Client: " + chatMessage.getMessage());
                ChatMessage reply = ChatMessage.newBuilder()
                        .setMessage("server: " + chatMessage.getMessage())
                        .build();
                responseObserver.onNext(reply);
            }

            @Override
            public void onError(Throwable throwable) {
                throwable.printStackTrace();
            }

            @Override
            public void onCompleted() {
                responseObserver.onCompleted();
            }
        };
    }
}
